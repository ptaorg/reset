# QA_REPORT

```json
{
  "version": "v0.2.2-rich-site",
  "html_files": 26,
  "template_html_files": 14,
  "source_markdown_files": 33,
  "internal_links_checked": 439,
  "broken_links": [],
  "manual_lines": 773
}
```
